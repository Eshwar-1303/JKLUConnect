export const avatarDb = [
  "https://res.cloudinary.com/dqlasoiaw/image/upload/v1687677292/tech-social/portrait-young-man-with-beard-hair-style-male-avatar-vector-illustration_266660-423_hdvup0.jpg",
  "https://res.cloudinary.com/dqlasoiaw/image/upload/v1687677608/tech-social/Cartoon-Avatar-White-Background-300x300_tucplb.png",
  "https://res.cloudinary.com/dqlasoiaw/image/upload/v1687677688/tech-social/360_F_279669366_Lk12QalYQKMczLEa4ySjhaLtx1M2u7e6_gu0tvw.jpg",
  "https://res.cloudinary.com/dqlasoiaw/image/upload/v1687678247/tech-social/young-pretty-fashion-african-girl-wearing-sunglasses-curly-black-hair-dark-skin-smiling_550427-137_nrgqxt.jpg",
  "https://res.cloudinary.com/dqlasoiaw/image/upload/v1687677608/tech-social/3d-illustration-person-with-sunglasses_23-2149436188_sazdtt.jpg",
  "https://res.cloudinary.com/dqlasoiaw/image/upload/v1687678246/tech-social/portrait-of-a-dark-skinned-young-woman-in-glasses-smiling-african-girl-with-curly-hair-and_o8kpe8.jpg",
  "https://res.cloudinary.com/dqlasoiaw/image/upload/v1687677609/tech-social/merida-avatar-wodp_k7w5dp.png",
  "https://res.cloudinary.com/dqlasoiaw/image/upload/v1687677608/tech-social/icon-256x256_snp1ay.png",
];
